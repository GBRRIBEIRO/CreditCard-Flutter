package com.example.cardflip

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
